CREATE DATABASE tcc_presenca;

USE tcc_presenca;

CREATE TABLE professores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    uid VARCHAR(20) NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS aulas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    professor_id INT NOT NULL,
    data_hora DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    acao ENUM('abrir','fechar') NOT NULL,

    CONSTRAINT fk_professor
        FOREIGN KEY (professor_id)
        REFERENCES professores(id)
);

INSERT INTO professores (nome, uid)
VALUES ('Marcelo', '1C8D8005');

SELECT * FROM professores;
SELECT * FROM aulas;

SHOW TABLES;
SHOW DATABASES;
